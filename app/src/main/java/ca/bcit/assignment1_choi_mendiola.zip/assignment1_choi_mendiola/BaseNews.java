package ca.bcit.assignment1_choi_mendiola;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class BaseNews{
    @SerializedName("news")
    @Expose
    private List<News> news = new ArrayList<News>();

    public List<News> getBaseNews() {
        return news;
    }

    public void setBaseNews(List<News> news) {
        this.news = news;
    }


}
