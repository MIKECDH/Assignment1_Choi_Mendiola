package ca.bcit.assignment1_choi_mendiola;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Query extends AppCompatActivity {
    private String api = "https://newsapi.org/v2/everything?q=&from=2020-02-10&sortBy=publishedAt&apiKey=465c153296d849b28cbec5866a76519b";
    private static String[] apiKey = new String[1];
    private String api2 = "";


    private static final int INDEX = 35;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query);

        Button search_btn1 = findViewById(R.id.search_button);
        search_btn1.setOnClickListener(btnLstnr);

    }

    public static String getApi() {
        return apiKey[0];
    }

//    private void set_Api() {
//        apiKey[0] = insertString(api, search_query(), INDEX);
//        System.out.print(apiKey[0]);
//    }

    private String search_query() {
        EditText get_word = findViewById(R.id.search);
        String searched_word = get_word.getText().toString();
        return searched_word;
    }

    public static String insertString(
            String originalString,
            String stringToBeInserted,
            int index) {

        // Create a new string
        String newString = new String();

        for (int i = 0; i < originalString.length(); i++) {

            // Insert the original string character
            // into the new string
            newString += originalString.charAt(i);

            if (i == index) {

                // Insert the string to be inserted
                // into the new string
                newString += stringToBeInserted;
            }
        }
        // return the modified String
        return newString;
    }

    private View.OnClickListener btnLstnr = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String searched = search_query();
            apiKey[0] = insertString(api, searched, INDEX);
            Intent intent = new Intent(Query.this, Article_List_Activity.class);
//            intent.putExtra("apiKey", final_query);
            startActivity(intent);
        }
    };
}
