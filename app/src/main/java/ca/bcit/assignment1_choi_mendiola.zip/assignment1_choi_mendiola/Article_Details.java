package ca.bcit.assignment1_choi_mendiola;

import androidx.appcompat.app.AppCompatActivity;

public class Article_Details extends AppCompatActivity {

}
